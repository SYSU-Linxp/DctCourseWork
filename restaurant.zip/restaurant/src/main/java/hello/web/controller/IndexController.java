package hello.web.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;

import hello.application.SpringServletInitializer;
import hello.business.entities.Customer;
import hello.business.entities.Dish;
import hello.business.entities.Order;
import hello.business.services.CustomerService;
import hello.business.services.DishService;
import hello.business.services.OrderService;
import hello.config.PersistenceJDBCConfig;

/**
 * Created by young on 16-11-2.
 */
@Controller
@RequestMapping("/index")
public class IndexController {
	
	public IndexController() {
		
		SpringServletInitializer servletInitializer = null;	

		DishService dishService = servletInitializer.context.getBean(DishService.class);
		CustomerService customerService = servletInitializer.context.getBean(CustomerService.class);
		OrderService orderService = servletInitializer.context.getBean(OrderService.class);
		
		final Order order = new Order(1,"Kevin", 19.8, "Potatoes", 2);
		final Dish dish = new Dish(1, "Golden Potatoes", true, 9.9);
		final Customer customer = new Customer(1, "Kevin");
		
		orderService.create(order);
		dishService.create(dish);
		customerService.create(customer);
	}
	
	@Autowired
	private DishService dishService;
	
	@ModelAttribute("dish") 
	public Dish getDish(Integer id) {
		return dishService.findById(id);
	}
	
    @GetMapping
    public String IndexPage(Model model) {
    	
        model.addAttribute("title", "首页");
        return "index";
    }
}
