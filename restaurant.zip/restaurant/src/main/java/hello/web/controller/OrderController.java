package hello.web.controller;

import org.hibernate.sql.ordering.antlr.GeneratedOrderByFragmentParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import hello.business.entities.Order;
import hello.business.services.OrderService;

/**
 * Created by young on 16-11-2.
 */
@Controller
@RequestMapping("/order/{id}")
public class OrderController {
	
	@Autowired
	private OrderService orderService;
	
	@ModelAttribute("order")
	public Order getOrder(Integer orderId) {
		return this.orderService.findById(orderId);
	}
	
    @GetMapping
    public String finishOrder(@PathVariable Integer id) {
    	getOrder(id);
        return "order";
    }
}
