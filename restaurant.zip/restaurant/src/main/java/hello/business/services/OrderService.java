package hello.business.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hello.business.dao.OrderDao;
import hello.business.entities.Order;

@Service
@Transactional
public class OrderService {
	@Autowired
	private OrderDao orderRepository;
	
	public OrderService() {
        super();
    }
    
    public void create(final Order entity) {
    	orderRepository.create(entity);
    }
    
    public List<Order> findAll() {
        return orderRepository.findAll();
    }

    public Order findById(final Integer id) {
        return orderRepository.findOne(id);
    }
}
