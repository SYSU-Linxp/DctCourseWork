package hello.business.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hello.business.dao.CustomerDao;
import hello.business.entities.Customer;


@Service
@Transactional
public class CustomerService {
	@Autowired
	private CustomerDao dao;
    
    public CustomerService() {
        super();
    }
    
    public void create(final Customer entity) {
        dao.create(entity);
    }
    
    public List<Customer> findAll() {
        return dao.findAll();
    }

   
    public Customer findById(final Integer id) {
        return dao.findOne(id);
    }
    
}
