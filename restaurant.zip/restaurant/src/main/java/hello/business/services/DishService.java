package hello.business.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import hello.business.dao.DishDao;
import hello.business.entities.Dish;

@Service
@Transactional
public class DishService {
	
	@Autowired
	private DishDao dishDao;
	
	public DishService() {
		super();
	}
	
	public void create (final Dish entity) {
		dishDao.create(entity);
	}
	
	public List<Dish> findAll() {
        return dishDao.findAll();
    }

    public Dish findById(final Integer id) {
        return dishDao.findOne(id);
    }
	
}
