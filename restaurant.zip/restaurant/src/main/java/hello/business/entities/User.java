package hello.business.entities;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class User {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Integer id = null;
	
	@Column(name = "userName")
    private String userName = null;
	
	@Column(name = "userPassword")
    private String userPassword = null;
	
	
    public User(final String userName, final String userPassword) {
        super();
        this.userName = userName;
        this.userPassword = userPassword;
    }

    public Integer getId() {
        return this.id;
    }
    
    public String getUserName() {
        return this.userName;
    }

    public String getUserPassword() {
        return this.userPassword;
    }
}
