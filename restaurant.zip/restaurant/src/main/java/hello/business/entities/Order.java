package hello.business.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.google.common.base.FinalizablePhantomReference;

@Entity
public class Order implements Serializable {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private Integer id = null;
	
	@Column(name = "customerName")
	private String customerName = null;
	
	@Column(name = "expenditure")
	private Double expenditure = null;
	
	@Column(name = "dishName")
	private String dishNames = null;
	
	@Column(name = "dishCount")
	private Integer dishCount = null;
	
	public Order() {
        super();
    }

    public Order(final Integer id, final String customerName, final Double expenditure, final String dishNames, final Integer dishCount) {
		this.id = id;
    	this.customerName = customerName;
		this.expenditure = expenditure;
		this.dishNames = dishNames;
		this.dishCount = dishCount;
	}
	
    public Integer getId() {
        return this.id;
    }
    public void setId(final Integer id) {
        this.id = id;
    }
    
    public void setExpenditure (Double expenditure) {
		this.expenditure = expenditure;
	}
    
    public Double getExpenditure() {
		return this.expenditure;
	}
    
    public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
    
    public String getCustomerName() {
		return this.customerName;
	}
    
    public void setDishNameList(String dishNames) {
		this.dishNames = dishNames;
	}
    
    public String getDishNameList() {
		return this.dishNames;
	}
    
    public void setDishCount (Integer dishCount) {
		this.dishCount = dishCount;
	}
    
    public Integer getDishCount() {
		return this.dishCount;
	}
    
}
