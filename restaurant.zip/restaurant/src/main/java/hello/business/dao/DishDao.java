package hello.business.dao;

import java.util.List;

import hello.business.entities.Dish;

public interface DishDao {
	List<Dish> findAll();
	
	Dish findOne(final Integer id);
	
	void create(Dish entity);
}
