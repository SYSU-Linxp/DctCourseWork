package hello.business.dao;

import java.util.List;

import hello.business.entities.Order;

public interface OrderDao {
	List<Order> findAll();
	
	Order findOne(final Integer id);
	
	void create(Order entity);
}
