package hello.business.dao;

import java.util.List;

import hello.business.entities.Customer;

public interface CustomerDao {
	List<Customer> findAll();
	
	Customer findOne(Integer id);
	
	void create(Customer entity);
}
